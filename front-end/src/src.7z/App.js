import React from 'react';
import './App.css';
import {Router, Route, Switch, Redirect } from "react-router-dom";
import Login from "./components/Login";
import ControllerLogin from "./classes/ControllerLogin";
import BarNav from "./components/BarNav";
import Signup from "./components/Signup";
import CustomerOptions from "./components/CustomerOptions";
import history from "./history";

export class App extends React.Component {
    the_controller = new ControllerLogin();
    state = {
        logged_user: ''
    }

   /* openLogin = () => {
        this.setState({ loginVisible: true });
        this.closeCustomerOption()

    }

    closeLogin = () => {
        this.setState({ loginVisible: false })
        this.openCustomerOption()
    }

    closeLogin = (logged_in_user) => {
        console.log("wewew")
        this.setState({ loginVisible: false, logged_user: logged_in_user}, console.log(this.state))
        this.openCustomerOption()
    }

    openCustomerOption = () => {
        this.setState({ customerOptionVisible: true })
    }
    closeCustomerOption = () => {
        this.setState({ customerOptionVisible: false })
    }*/

    render() {
        return (
            <div className="App">
                <BarNav/>

                <Router history={ history }>
                    <Switch>
                        <Route exact path="/" render={() => history.push("/login")} />
                        <Route path="/" component={Login} />
                        <Route path="/mainmenu" component={CustomerOptions}/>
                        <Route path="/signup" component={Signup}/>
                    </Switch>
                </Router>
            </div>
        );
    }
}

export default App;
