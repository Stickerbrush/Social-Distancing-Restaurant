import React, { Component } from "react";
import { Button, Form } from 'react-bootstrap';
import history from '../history';
import "./LoginStyle.css";

export class Login extends Component {
    fetch_addr = 'http://localhost:5000';
    state = {
        mostrar: true,
        datos_cliente: '',
        cedula: '',
        password: '',
        trabajador: false,
        sending: false
    };

    constructor(props) {
        super(props)
        this.getCliente = this.getCliente.bind(this);
        this.getEmpleado = this.getEmpleado.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.validateLogin = this.validateLogin.bind(this);
        this.handleToggleButton = this.handleToggleButton.bind(this);
        this.componentWillUnmount = this.componentWillUnmount.bind(this);
        this.changeRoute = this.changeRoute.bind(this);
    }

    componentWillUnmount() {
        this.setState = (state,callback)=>{
            return null;
        };
    }

    changeRoute() {
        let path = '/mainmenu';
        history.push(path);
    }

    validateLogin(data) {
        console.log(data)
        console.log(data.length > 2)
        if(data.length > 2){
            alert(data.toString())
            this.changeRoute()
           // this.props.clickCerrarLogin(this.state.datos_cliente)
        } else{
            alert("Login fallido, porfavor escriba las credenciales correctas");
        }
    }

    handleChange(e){
        const {name, value} = e.target
        this.setState({[name]: value});
    }

    handleToggleButton(e){
        if(this.state.trabajador){
            this.setState({trabajador: false})
        } else {
            this.setState({trabajador: true})
        }
    }

    handleSubmit(e) {
        e.preventDefault();
        const cedula = this.state.cedula;
        const contrasena =  this.state.password;
        if(this.state.trabajador){
            this.setState({sending: true}, this.getEmpleado(cedula, contrasena))
        } else {
            this.setState({sending: true}, this.getCliente(cedula, contrasena));
        }
    }

    getEmpleado(empleado_id, contrasena_empleado){
        let empleado = parseInt(empleado_id);
        fetch(this.fetch_addr + "/empleados/"+  empleado + "/"+ contrasena_empleado)
            .then(response => {
                return response.text();
            })
            .then(data => {
                this.setState ({datos_cliente: data, sending: false},
                    this.validateLogin(data))
            });
    }

    getCliente(cedula_cliente, contrasena_cliente){
        let cedula = parseInt(cedula_cliente);
        fetch(this.fetch_addr + "/clientes/"+  cedula+ "/"+ contrasena_cliente)
        .then(response => {
            return response.text();
        })
        .then(data => {
            this.setState ({datos_cliente: data, sending: false},
                                this.validateLogin(data))
        });
    }

    render() {
        return (
                <div className="loginContainer">
                <div className="loginContainerHijo">
                    <Form onSubmit= {this.handleSubmit}>

                        <Form.Group controlId="formBasicEmail">
                            <Form.Text className="text-titulo" >
                                Iniciar Sesión
                            </Form.Text>
                            <Form.Control type="number"
                                          placeholder={this.state.trabajador ? "ID Trabajador" :"Cedula"}
                                          name="cedula"
                                          onChange={this.handleChange}
                            />
                        </Form.Group>


                        <Form.Group controlId="formBasicPassword">
                            <Form.Control type="password"
                                          name="password"
                                          placeholder="Contraseña"
                                          onChange={this.handleChange}
                            />
                        </Form.Group>
                        <Form.Group controlId="formBasicCheckbox">
                            <Form.Check
                                inline
                                type="switch"
                                id="custom-switch"
                                name = "trabajador"
                                label="Trabajador?"
                                className="check-switch"
                                onChange={this.handleToggleButton}
                            />
                        </Form.Group>
                        <Button
                            variant="default"
                            type="submit"
                            disabled={this.state.sending}
                            style={{ color: "white", background: "#FF834E" }}>
                            Acceder
                        </Button>
                    </Form>
                </div>
            </div >
        );
    }
}
export default Login;
