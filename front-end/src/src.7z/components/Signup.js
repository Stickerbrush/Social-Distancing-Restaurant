import React from "react";
import Login from "./Login";

export class Signup extends React.Component {


    constructor(props) {
        super(props)

    }
}

export default Signup;
