import React, {Component} from "react";
import {Button} from "react-bootstrap";

export class ControllerLogin extends Component{
    state = {
        response: '',
        post: '',
        responseToPost: '',
    };

    constructor(props){
        super(props);
        this.getCliente = this.getCliente.bind(this);
        this.createCliente = this.createCliente.bind(this);
        this.deleteCliente = this.deleteCliente.bind(this);
    }

    //fetch_addr = 'https://s-d-r-backend.herokuapp.com'
    fetch_addr = 'http://localhost:5000';
   /* const [clientes, setClientes] = useState(false);
        useEffect(() => {
        getCliente();
    }, []);*/


    getCliente() {
        //fetch('https://s-d-r-backend.herokuapp.com')
            fetch(this.fetch_addr)
            .then(response => {
               return response.text();
            })
            .then(data => {
                this.setState ({response: data});
            });
            return this.the_response;
    }

    createCliente() {
        let telefono = prompt('Enter client phone number');
        let nombre = prompt('Enter client name');
        fetch(this.fetch_addr, {
            //fetch('http://localhost:5000/clientes', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ telefono, nombre }),
        })
            .then(response => {
                return response.text();
            })
            .then(data => {
                alert(data);
                this.setState ({response: data});
            });
    }

    deleteCliente() {
        let telefono = prompt('Enter client phone number');
        fetch(this.fetch_addr + `/telefono/${telefono}`, {
            //fetch('http://localhost:5000/clientes/${telefono}', {
            method: 'DELETE',
        })
            .then(response => {
                return response.text();
            })
            .then(data => {
                alert(data);
                this.setState ({response: data});
            });
    }


    render() {
        return(
            <div>
                <button onClick={this.getCliente}>XD merchant </button>
                <p> {this.state.response ? this.state.response : 'There is no client data available'}</p>

                <button onClick={this.createCliente}>Add merchant </button>
                <br />
                <button onClick={this.deleteCliente}>Delete merchant</button>
            </div>


        );
    }
}

export default ControllerLogin;
